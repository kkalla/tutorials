def add(x, y):
    return x + y


def test_add():
    assert add(1, 2) == 3